__title__ = "pygal"
__version__ = "3.1.3"

__summary__ = "A Python svg graph plotting library"
__uri__ = "https://www.pygal.org/"
__author__ = "Kozea"
__email__ = "dev@kozea.fr"

__license__ = "GNU LGPL v3+"
__copyright__ = "Copyright 2020 %s" % __author__

__all__ = [
    '__title__', '__version__', '__summary__', '__uri__', '__author__',
    '__email__', '__license__', '__copyright__'
]
